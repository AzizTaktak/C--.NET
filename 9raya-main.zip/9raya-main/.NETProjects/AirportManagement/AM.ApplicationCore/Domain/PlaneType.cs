﻿namespace AM.ApplicationCore.Domain
{
    public enum PlaneType
    {
        Boing, Airbus
    }
}
