package tn.esprit.tp1.entity;

public enum Specialite {

    IA, RESEAUX, CLOUD, SECURITE
}
