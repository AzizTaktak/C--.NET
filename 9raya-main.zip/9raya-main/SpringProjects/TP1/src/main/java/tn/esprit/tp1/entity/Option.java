package tn.esprit.tp1.entity;

public enum Option {

    GAMIX, SIM, SE, NIDS
}

