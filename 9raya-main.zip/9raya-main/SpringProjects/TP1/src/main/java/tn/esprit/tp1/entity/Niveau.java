package tn.esprit.tp1.entity;

public enum Niveau {

    JUNIOR, SENIOR, EXPERT
}
